let activeCategory = "All";
let searchQuery = "";
let vegOnly = false;
let cart = [];

const categoryBar = document.getElementById("categoryBar");
const menuGrid = document.getElementById("menuGrid");
const menuTitle = document.getElementById("menuTitle");
const menuSubtitle = document.getElementById("menuSubtitle");
const searchInput = document.getElementById("searchInput");
const vegOnlyToggle = document.getElementById("vegOnlyToggle");

const itemModal = document.getElementById("itemModal");
const modalBody = document.getElementById("modalBody");
const closeItemModal = document.getElementById("closeItemModal");

const cartDrawer = document.getElementById("cartDrawer");
const cartBackdrop = document.getElementById("cartBackdrop");
const openCartBtn = document.getElementById("openCartBtn");
const closeCartBtn = document.getElementById("closeCartBtn");
const cartCount = document.getElementById("cartCount");
const cartItemsContainer = document.getElementById("cartItemsContainer");
const subtotalAmount = document.getElementById("subtotalAmount");
const taxAmount = document.getElementById("taxAmount");
const totalAmount = document.getElementById("totalAmount");
const proceedCheckoutBtn = document.getElementById("proceedCheckoutBtn");

const checkoutModal = document.getElementById("checkoutModal");
const checkoutContent = document.getElementById("checkoutContent");
const closeCheckoutModal = document.getElementById("closeCheckoutModal");
const toast = document.getElementById("toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

function renderCategories() {
  const categories = ["All", ...new Set(MENU_ITEMS.map((item) => item.category))];
  categoryBar.innerHTML = categories
    .map(
      (cat) => `
      <button
        class="category-pill ${cat === activeCategory ? "active" : ""}"
        data-category="${cat}"
        role="tab"
        aria-selected="${cat === activeCategory}"
      >
        ${cat}
      </button>
    `
    )
    .join("");

  categoryBar.querySelectorAll(".category-pill").forEach((btn) => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.category;
      renderCategories();
      renderMenu();
    });
  });
}

function renderMenu() {
  const filtered = MENU_ITEMS.filter((item) => {
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    const matchesVeg = !vegOnly || item.veg;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery) ||
      item.shortDesc.toLowerCase().includes(searchQuery) ||
      item.category.toLowerCase().includes(searchQuery);
    return matchesCategory && matchesVeg && matchesSearch;
  });

  menuTitle.textContent = activeCategory === "All" ? "All Menu Items" : `${activeCategory} Menu`;
  menuSubtitle.textContent = `Showing ${filtered.length} ${filtered.length === 1 ? "dish" : "dishes"}`;

  if (filtered.length === 0) {
    menuGrid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; background: #fff; border-radius: 14px; border: 1px solid #e5e7eb;">
        <h3>No matching dishes found</h3>
        <p style="color: #6b7280; margin-top: 0.4rem;">Try clearing your search filter or switching categories.</p>
      </div>
    `;
    return;
  }

  menuGrid.innerHTML = filtered
    .map(
      (item) => `
      <article class="food-card">
        <div class="food-thumb">
          <img src="${item.image}" alt="${item.name}" loading="lazy" />
          <span class="diet-badge">
            <span class="diet-dot ${item.veg ? "veg" : "nonveg"}"></span>
            ${item.veg ? "Veg" : "Non-Veg"}
          </span>
          <span class="rating-pill">★ ${item.rating}</span>
        </div>
        <div class="food-body">
          <span class="food-meta">${item.category} • ${item.prepTime}</span>
          <h3 class="food-title">${item.name}</h3>
          <p class="food-desc">${item.shortDesc}</p>
          <div class="food-footer">
            <span class="food-price">₹${item.price}</span>
            <div class="card-actions">
              <button class="btn btn-outline btn-sm" onclick="openItemDetails(${item.id})">Details</button>
              <button class="btn btn-primary btn-sm" onclick="addToCart(${item.id})">+ Add</button>
            </div>
          </div>
        </div>
      </article>
    `
    )
    .join("");
}

function openItemDetails(id) {
  const item = MENU_ITEMS.find((entry) => entry.id === id);
  if (!item) return;

  modalBody.innerHTML = `
    <img class="modal-hero-img" src="${item.image}" alt="${item.name}" />
    <div class="modal-info">
      <span class="food-meta">${item.category} • ${item.veg ? "Pure Vegetarian" : "Non-Vegetarian"}</span>
      <h2 id="modalDishTitle" style="margin: 0.25rem 0 0.5rem;">${item.name}</h2>
      <p style="color: #4b5563; font-size: 0.95rem;">${item.shortDesc}</p>

      <div class="modal-specs">
        <div><span>Portion Size</span><strong>${item.portion}</strong></div>
        <div><span>Prep Time</span><strong>${item.prepTime}</strong></div>
        <div><span>Energy</span><strong>${item.calories}</strong></div>
      </div>

      <p style="font-size: 0.9rem; margin-bottom: 1.25rem;">
        <strong>Key Ingredients:</strong> <span style="color: #4b5563;">${item.ingredients}</span>
      </p>

      <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem;">
        <span style="font-size: 1.35rem; font-weight: 800;">₹${item.price}</span>
        <button class="btn btn-primary" onclick="addToCart(${item.id}); closeDetailsModal();">
          Add to Order Review
        </button>
      </div>
    </div>
  `;

  itemModal.classList.add("open");
  itemModal.setAttribute("aria-hidden", "false");
}

function closeDetailsModal() {
  itemModal.classList.remove("open");
  itemModal.setAttribute("aria-hidden", "true");
}

function addToCart(id) {
  const item = MENU_ITEMS.find((entry) => entry.id === id);
  if (!item) return;

  const existing = cart.find((entry) => entry.id === id);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ ...item, qty: 1 });
  }

  updateCartUI();
  showToast(`Added "${item.name}" to Order Review`);
}

function updateQuantity(id, delta) {
  const index = cart.findIndex((entry) => entry.id === id);
  if (index === -1) return;

  cart[index].qty += delta;
  if (cart[index].qty <= 0) {
    cart.splice(index, 1);
  }
  updateCartUI();
}

function updateCartUI() {
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  cartCount.textContent = totalItems;

  if (cart.length === 0) {
    cartItemsContainer.innerHTML = `
      <div style="text-align: center; padding: 3rem 1rem; color: #6b7280;">
        <p style="font-weight: 700; color: #111827; margin-bottom: 0.35rem;">Your order review list is empty</p>
        <p style="font-size: 0.9rem;">Select items from the menu to inspect quantities and pricing.</p>
      </div>
    `;
    subtotalAmount.textContent = "₹0";
    taxAmount.textContent = "₹0";
    totalAmount.textContent = "₹0";
    proceedCheckoutBtn.disabled = true;
    proceedCheckoutBtn.style.opacity = "0.5";
    return;
  }

  proceedCheckoutBtn.disabled = false;
  proceedCheckoutBtn.style.opacity = "1";

  cartItemsContainer.innerHTML = cart
    .map(
      (item) => `
      <div class="cart-item">
        <div class="cart-item-info">
          <h4>${item.name}</h4>
          <span>₹${item.price} &times; ${item.qty} = <strong>₹${item.price * item.qty}</strong></span>
        </div>
        <div class="qty-controls">
          <button class="qty-btn" onclick="updateQuantity(${item.id}, -1)" aria-label="Decrease quantity">-</button>
          <span>${item.qty}</span>
          <button class="qty-btn" onclick="updateQuantity(${item.id}, 1)" aria-label="Increase quantity">+</button>
        </div>
      </div>
    `
    )
    .join("");

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + tax;

  subtotalAmount.textContent = `₹${subtotal}`;
  taxAmount.textContent = `₹${tax}`;
  totalAmount.textContent = `₹${total}`;
}

function toggleCart(open) {
  cartDrawer.classList.toggle("open", open);
  cartBackdrop.classList.toggle("open", open);
  cartDrawer.setAttribute("aria-hidden", String(!open));
}

searchInput.addEventListener("input", (e) => {
  searchQuery = e.target.value.trim().toLowerCase();
  renderMenu();
});

vegOnlyToggle.addEventListener("change", (e) => {
  vegOnly = e.target.checked;
  renderMenu();
});

closeItemModal.addEventListener("click", closeDetailsModal);
itemModal.addEventListener("click", (e) => {
  if (e.target === itemModal) closeDetailsModal();
});

openCartBtn.addEventListener("click", () => toggleCart(true));
closeCartBtn.addEventListener("click", () => toggleCart(false));
cartBackdrop.addEventListener("click", () => toggleCart(false));

proceedCheckoutBtn.addEventListener("click", () => {
  if (cart.length === 0) return;
  toggleCart(false);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const total = subtotal + Math.round(subtotal * 0.05);

  checkoutContent.innerHTML = `
    <span class="pill-tag">UI Prototype Step</span>
    <h2>Order Summary Preview</h2>
    <p style="color: #4b5563; margin-top: 0.4rem;">
      Your selection of <strong>${cart.reduce((s, i) => s + i.qty, 0)} item(s)</strong> totaling <strong>₹${total}</strong> is ready.
    </p>
    <div class="demo-notice">
      <strong>Prototype Scope Notice:</strong> This is a frontend UI demonstration. Live payment gateways, backend database storage, and delivery partner dispatch are outside the scope of this UI build.
    </div>
    <button class="btn btn-primary btn-full" id="resetDemoBtn">Complete Preview &amp; Clear Selection</button>
  `;

  checkoutModal.classList.add("open");
  checkoutModal.setAttribute("aria-hidden", "false");

  document.getElementById("resetDemoBtn").addEventListener("click", () => {
    cart = [];
    updateCartUI();
    checkoutModal.classList.remove("open");
    showToast("Demo flow completed");
  });
});

closeCheckoutModal.addEventListener("click", () => {
  checkoutModal.classList.remove("open");
});

renderCategories();
renderMenu();
updateCartUI();
