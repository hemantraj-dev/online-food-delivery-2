# Online Food Ordering UI

Frontend web application prototype developed by **Krishna Kumar** (Chandigarh University) during an internship at **GadGet Technology Services** under the guidance of the **Appplus Web Team** (4 June 2026 – 11 July 2026).

## Folder Structure
- `index.html`: Semantic page structure covering Home, Categories, Food Menu, Item Details Modal, Order Review Drawer, and Checkout Preview.
- `css/style.css`: Responsive layout, visual hierarchy, card grid, and interactive state styling.
- `js/data.js`: Sample structured food catalog.
- `js/app.js`: Category filtering, instant search, Pure Veg toggle, modal details view, and live cart calculation.

## How to Run in VS Code
1. Open the `online-food-ordering-ui` folder in VS Code.
2. Install the **Live Server** extension (by Ritwick Dey) if not already installed.
3. Right-click `index.html` and select **Open with Live Server**.
